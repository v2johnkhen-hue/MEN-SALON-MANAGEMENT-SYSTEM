<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
  } else{

  

  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>MSMS |  Sales Reports</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
	 <?php include_once('includes/header.php');?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h3 class="title1">Sales reports</h3>
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Sales reports:</h4>
						</div>
						<div class="form-body">
							<form method="post" name="bwdatesreport"  action="sales-reports-detail.php" enctype="multipart/form-data">
								

  
							 <div class="form-group"> <label for="exampleInputEmail1">From Date</label> <input type="date" class="form-control1" name="fromdate" id="fromdate" value="" required='true'> </div> 
							 <div class="form-group"> <label for="exampleInputPassword1">To Date</label><input type="date" class="form-control1" name="todate" id="todate" value="" required='true'> </div>
							 <div class="form-group"> <label for="exampleInputPassword1">Request Type</label><input type="radio" name="requesttype" value="mtwise" checked="true">Month wise
                  <input type="radio" name="requesttype" value="yrwise">Year wise </div>
							 
							
							
							  <button type="submit" name="submit" class="btn btn-default">Submit</button> </form> 
						</div>
						
					</div>



					<div class="row calender widget-shadow">
    <div class="row-one">
        <?php
        // Fetch data from the database
        $query1 = mysqli_query($con, "Select * from tblcustomers");
        $totalcust = mysqli_num_rows($query1);

        $query2 = mysqli_query($con, "Select * from tblappointment");
        $totalappointment = mysqli_num_rows($query2);

        $query3 = mysqli_query($con, "Select * from tblappointment where Status='1'");
        $totalaccapt = mysqli_num_rows($query3);
        ?>

        <!-- Div element for Highcharts -->
        <div id="myBarChart" style="width: 100%; height: 400px;"></div>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                // Data from PHP
                const totalCustomers = <?php echo $totalcust; ?>;
                const totalAppointments = <?php echo $totalappointment; ?>;
                const totalAcceptedApt = <?php echo $totalaccapt; ?>;

                // Initialize Highcharts
                Highcharts.chart('myBarChart', {
                    chart: {
                        type: 'column' // Bar chart is represented as 'column' in Highcharts
                    },
                    title: {
                        text: 'Total Overview'
                    },
                    xAxis: {
                        categories: ['Customers', 'Appointments', 'Accepted Appointments']
                    },
                    yAxis: {
                        title: {
                            text: 'Total Count'
                        },
                        allowDecimals: false
                    },
                    series: [{
                        name: 'Totals',
                        data: [totalCustomers, totalAppointments, totalAcceptedApt],
                        colorByPoint: true
                    }],
                    plotOptions: {
                        column: {
                            dataLabels: {
                                enabled: true
                            }
                        }
                    }
                });
            });
        </script>
    </div>
</div>


<div class="row calender widget-shadow">
    <div class="row-two">
        <?php
        // Fetch data from the database
        $query4 = mysqli_query($con, "Select * from tblappointment where Status='1'");
        $totalrejapt = mysqli_num_rows($query4);

        $query5 = mysqli_query($con, "Select * from tblservices");
        $totalser = mysqli_num_rows($query5);

        $query6 = mysqli_query($con, "select tblinvoice.ServiceId as ServiceId, tblservices.Cost
                                       from tblinvoice 
                                       join tblservices on tblservices.ID=tblinvoice.ServiceId 
                                       where date(PostingDate)=CURDATE();");
        $todysale = 0;
        while ($row = mysqli_fetch_array($query6)) {
            $todysale += $row['Cost'];
        }
        ?>

        <!-- Div element for Highcharts -->
        <div id="secondRowChart" style="width: 100%; height: 400px;"></div>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                // Data from PHP
                const totalRejectedApt = <?php echo $totalrejapt; ?>;
                const totalServices = <?php echo $totalser; ?>;
                const todaysSales = <?php echo ($todysale == '') ? 0 : $todysale; ?>;

                // Initialize Highcharts
                Highcharts.chart('secondRowChart', {
                    chart: {
                        type: 'column' // Bar chart is represented as 'column' in Highcharts
                    },
                    title: {
                        text: 'Services and Sales Overview'
                    },
                    xAxis: {
                        categories: ['Rejected Appointments', 'Total Services', 'Today\'s Sales']
                    },
                    yAxis: {
                        title: {
                            text: 'Total Count'
                        },
                        allowDecimals: false
                    },
                    series: [{
                        name: 'Totals',
                        data: [totalRejectedApt, totalServices, todaysSales],
                        colorByPoint: true
                    }],
                    plotOptions: {
                        column: {
                            dataLabels: {
                                enabled: true
                            }
                        }
                    }
                });
            });
        </script>
    </div>
</div>




<div class="row calender widget-shadow">
    <div class="row-three">
        <?php
        // Yesterday's Sale
        $query7 = mysqli_query($con, "select tblinvoice.ServiceId as ServiceId, tblservices.Cost
                                      from tblinvoice 
                                      join tblservices on tblservices.ID=tblinvoice.ServiceId 
                                      where date(PostingDate)=CURDATE()-1;");
        $yesterdaysale = 0;
        while ($row7 = mysqli_fetch_array($query7)) {
            $yesterdaysale += $row7['Cost'];
        }

        // Last 7 Days Sales
        $query8 = mysqli_query($con, "select tblinvoice.ServiceId as ServiceId, tblservices.Cost
                                      from tblinvoice 
                                      join tblservices on tblservices.ID=tblinvoice.ServiceId 
                                      where date(PostingDate)>=(DATE(NOW()) - INTERVAL 7 DAY);");
        $tseven = 0;
        while ($row8 = mysqli_fetch_array($query8)) {
            $tseven += $row8['Cost'];
        }

        // Total Sales
        $query9 = mysqli_query($con, "select tblinvoice.ServiceId as ServiceId, tblservices.Cost
                                      from tblinvoice 
                                      join tblservices on tblservices.ID=tblinvoice.ServiceId");
        $totalsale = 0;
        while ($row9 = mysqli_fetch_array($query9)) {
            $totalsale += $row9['Cost'];
        }
        ?>

        <!-- Div element for Highcharts -->
        <div id="thirdRowChart" style="width: 100%; height: 400px;"></div>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                // Data from PHP
                const yesterdaysSale = <?php echo ($yesterdaysale == '') ? 0 : $yesterdaysale; ?>;
                const last7DaysSale = <?php echo ($tseven == '') ? 0 : $tseven; ?>;
                const totalSale = <?php echo ($totalsale == '') ? 0 : $totalsale; ?>;

                // Initialize Highcharts
                Highcharts.chart('thirdRowChart', {
                    chart: {
                        type: 'column' // Bar chart is represented as 'column' in Highcharts
                    },
                    title: {
                        text: 'Sales Overview'
                    },
                    xAxis: {
                        categories: ['Yesterday\'s Sales', 'Last 7 Days Sales', 'Total Sales']
                    },
                    yAxis: {
                        title: {
                            text: 'Total Sales (in currency)'
                        },
                        allowDecimals: true
                    },
                    series: [{
                        name: 'Sales',
                        data: [yesterdaysSale, last7DaysSale, totalSale],
                        colorByPoint: true
                    }],
                    plotOptions: {
                        column: {
                            dataLabels: {
                                enabled: true
                            }
                        }
                    }
                });
            });
        </script>
    </div>
</div>
				
				
			</div>
		</div>
		 <?php include_once('includes/footer.php');?>
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>
<?php } ?>